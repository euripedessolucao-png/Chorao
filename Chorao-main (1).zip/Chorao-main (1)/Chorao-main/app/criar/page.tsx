// app/create/page.tsx
import CreatePage from '../components/CreatePage'

export default function Create() {
  return <CreatePage />
}












