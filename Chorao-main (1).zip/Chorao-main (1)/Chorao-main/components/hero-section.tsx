// app/components/HomePage.tsx
'use client'

import React from 'react'
import { motion } from 'framer-motion'
import { useRouter } from 'next/navigation'
import { useQuery } from '@tanstack/react-query'
import { apiClient } from '~/client/api'
import { useAuth } from '~/client/utils'
import {
  Card,
  CardContent,
  CardFooter,
  CardHeader,
  CardTitle,
  Button,
  Badge,
} from '~/components/ui'
import {
  Music,
  Plus,
  Pencil,
  Calendar,
  Home,
  TrendingUp,
  Save,
  RefreshCw,
  LayoutGrid,
} from 'lucide-react'

function HomePage() {
  const auth = useAuth()
  const router = useRouter()
  const { data: projects = [] } = useQuery(
    ['projects'],
    apiClient.getProjects,
    {
      enabled: auth.status === 'authenticated',
    }
  )

  return (
    <div className="relative min-h-screen overflow-hidden">
      {/* Animated Music Notes Background */}
      <div className="absolute inset-0 overflow-hidden pointer-events-none">
        {[...Array(15)].map((_, i) => (
          <motion.div
            key={i}
            className="absolute text-primary/10 dark:text-primary/5"
            initial={{
              top: `${Math.random() * 100}%`,
              left: `${Math.random() * 100}%`,
              rotate: Math.random() * 360,
              scale: 0.5 + Math.random() * 1.5,
            }}
            animate={{
              top: [`${Math.random() * 100}%`, `${Math.random() * 100}%`],
              left: [`${Math.random() * 100}%`, `${Math.random() * 100}%`],
              rotate: [Math.random() * 360, Math.random() * 360],
              opacity: [0.1, 0.4, 0.1],
            }}
            transition={{
              duration: 15 + Math.random() * 20,
              repeat: Infinity,
              ease: 'linear',
            }}
            style={{ fontSize: `${2 + Math.random() * 4}rem` }}
          >
            {['♪', '♫', '♬', '♩', '♭', '♮', '♯', '𝄞', '𝄢', '𝄪'][
              Math.floor(Math.random() * 10)
            ]}
          </motion.div>
        ))}
      </div>

      <div className="w-full px-4 sm:px-6 md:px-8 py-8 max-w-none relative z-10">
        {/* Hero Section */}
        <section className="relative py-8 sm:py-12 mb-10 rounded-2xl overflow-hidden">
          <div className="absolute inset-0 bg-gradient-to-r from-primary/20 to-accent/30 backdrop-blur-sm dark:from-primary/10 dark:to-accent/20"></div>
          <div className="relative z-10 text-center px-4 py-12">
            <motion.h1
              className="text-3xl sm:text-4xl md:text-5xl font-bold mb-4 text-foreground"
              initial={{ opacity: 0, y: -20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.6 }}
            >
              Chorão - Compositor
            </motion.h1>
            <motion.p
              className="text-base sm:text-lg mb-6 max-w-3xl mx-auto text-foreground/80"
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.6, delay: 0.2 }}
            >
              Seu assistente de composição que cria letras originais em qualquer
              gênero, humor ou estilo. Edite, analise e aperfeiçoe suas letras
              em minutos.
              <br />
              <span className="block mt-3 text-primary font-semibold">
                Todo o conteúdo e as ferramentas do app seguem as principais
                metodologias e práticas de ensino musical reconhecidas no
                Brasil.
              </span>
            </motion.p>
            <motion.div
              initial={{ opacity: 0, scale: 0.9 }}
              animate={{ opacity: 1, scale: 1 }}
              transition={{ duration: 0.6, delay: 0.4 }}
            >
              <Button
                size="lg"
                onClick={() => router.push('/create')}
                className="bg-primary hover:bg-primary/90 text-primary-foreground px-6 py-3 text-base shadow-lg focus:ring-2 focus:ring-primary focus:ring-offset-2"
                aria-label="Criar Nova Letra"
              >
                <Music className="h-5 w-5 mr-2" /> Criar Nova Letra
              </Button>
            </motion.div>
          </div>
        </section>

        {/* Projects Section */}
        <section className="mb-12">
          <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between mb-6 gap-4">
            <motion.h2
              className="text-2xl sm:text-3xl font-bold"
              initial={{ opacity: 0, x: -20 }}
              animate={{ opacity: 1, x: 0 }}
              transition={{ duration: 0.5 }}
            >
              Seus Projetos
            </motion.h2>
            <motion.div
              initial={{ opacity: 0, x: 20 }}
              animate={{ opacity: 1, x: 0 }}
              transition={{ duration: 0.5 }}
            >
              <Button
                variant="outline"
                onClick={() => router.push('/create')}
                className="border-primary/20 hover:border-primary min-w-[120px]"
                aria-label="Criar Novo Projeto"
              >
                <Plus className="h-4 w-4 mr-2" />
                Novo Projeto
              </Button>
            </motion.div>
          </div>

          {auth.status === 'unauthenticated' ? (
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.5 }}
            >
              <Card className="border-2 border-primary/20 shadow-lg backdrop-blur-sm">
                <CardContent className="p-10 text-center">
                  <Music className="h-12 w-12 mx-auto mb-4 text-primary/60" />{' '}
                  <p className="text-lg mb-6">
                    Faça login para criar e salvar seus projetos de letras
                  </p>
                  <Button onClick={() => auth.signIn()} size="lg">
                    Entrar
                  </Button>
                </CardContent>
              </Card>
            </motion.div>
          ) : projects.length === 0 ? (
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.5 }}
            >
              <Card className="border-2 border-primary/20 shadow-lg backdrop-blur-sm">
                <CardContent className="p-10 text-center">
                  <Music className="h-12 w-12 mx-auto mb-4 text-primary/60" />{' '}
                  <p className="text-lg mb-6">
                    Você ainda não tem projetos de letras
                  </p>
                  <Button
                    onClick={() => router.push('/create')}
                    size="lg"
                    className="bg-primary hover:bg-primary/90 text-primary-foreground"
                  >
                    Criar Seu Primeiro Projeto
                  </Button>
                </CardContent>
              </Card>
            </motion.div>
          ) : (
            <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-4 md:gap-6">
              {projects.map((project: any, index: number) => (
                <motion.div
                  key={project.id}
                  initial={{ opacity: 0, y: 20 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ duration: 0.5, delay: index * 0.1 }}
                >
                  <Card className="h-full flex flex-col border border-primary/10 hover:border-primary/30 transition-all duration-300 shadow-md hover:shadow-lg backdrop-blur-sm">
                    <CardHeader className="border-b border-border/30 pb-3">
                      <CardTitle className="text-xl font-bold">
                        {project.title}
                      </CardTitle>
                    </CardHeader>
                    <CardContent className="flex-grow pt-4">
                      <div className="flex items-center mb-3 text-sm text-muted-foreground">
                        <Calendar className="h-4 w-4 mr-2" />
                        {new Date(project.updatedAt).toLocaleDateString()}
                        <Badge variant="outline" className="ml-2 text-xs">
                          {project.genre}
                        </Badge>
                      </div>
                      <p className="line-clamp-4 text-sm">
                        {project.lyrics.substring(0, 150)}...
                      </p>
                    </CardContent>
                    <CardFooter className="pt-3 border-t border-border/30">
                      <Button
                        variant="outline"
                        className="w-full hover:bg-primary/10"
                        onClick={() => router.push(`/editar/${project.id}`)}
                      >
                        <Pencil className="h-4 w-4 mr-2" />
                        Editar Letra
                      </Button>
                    </CardFooter>
                  </Card>
                </motion.div>
              ))}
            </div>
          )}
        </section>

        {/* Features Section */}
        <section className="py-6">
          <motion.h2
            className="text-2xl sm:text-3xl font-bold mb-8 text-center"
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.5 }}
          >
            Recursos
          </motion.h2>
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.5, delay: 0.1 }}
            >
              <Card className="h-full border-2 border-primary/40 hover:border-primary transition-all duration-300 shadow-md hover:shadow-lg backdrop-blur-sm">
                <CardHeader className="pb-2">
                  <div className="w-12 h-12 rounded-full bg-primary/10 flex items-center justify-center mx-auto mb-4">
                    <Music className="h-6 w-6 text-primary" />
                  </div>
                  <CardTitle className="text-center text-xl">
                    Gerar Letras
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <p className="text-center text-muted-foreground">
                    Crie letras originais em qualquer gênero, humor ou estilo
                    com apenas alguns cliques.
                  </p>
                  <div className="mt-6 text-center">
                    <Button
                      variant="outline"
                      className="hover:bg-primary/10"
                      onClick={() => router.push('/create')}
                    >
                      Começar Agora
                    </Button>
                  </div>
                </CardContent>
              </Card>
            </motion.div>

            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.5, delay: 0.2 }}
            >
              <Card className="h-full border-2 border-primary/40 hover:border-primary transition-all duration-300 shadow-md hover:shadow-lg backdrop-blur-sm">
                <CardHeader className="pb-2">
                  <div className="w-12 h-12 rounded-full bg-primary/10 flex items-center justify-center mx-auto mb-4">
                    <RefreshCw className="h-6 w-6 text-primary" />
                  </div>
                  <CardTitle className="text-center text-xl">
                    Reescrever Letras
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <p className="text-center text-muted-foreground">
                    Refine seções específicas das suas letras mantendo o fluxo
                    geral.
                  </p>
                  <div className="mt-6 text-center">
                    <Button
                      variant="outline"
                      className="hover:bg-primary/10"
                      onClick={() => router.push('/rewrite')}
                    >
                      <RefreshCw className="h-4 w-4 mr-2" />
                      Reescrever Agora
                    </Button>
                  </div>
                </CardContent>
              </Card>
            </motion.div>

            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.5, delay: 0.3 }}
            >
              <Card className="h-full border-2 border-primary/40 hover:border-primary transition-all duration-300 shadow-md hover:shadow-lg backdrop-blur-sm">
                <CardHeader className="pb-2">
                  <div className="w-12 h-12 rounded-full bg-primary/10 flex items-center justify-center mx-auto mb-4">
                    <Save className="h-6 w-6 text-primary" />
                  </div>
                  <CardTitle className="text-center text-xl">
                    Salvar Projetos
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <p className="text-center text-muted-foreground">
                    Organize e salve seus projetos de letras para fácil acesso e
                    edição.
                  </p>
                  <div className="mt-6 text-center">
                    <Button
                      variant="outline"
                      className="hover:bg-primary/10"
                      onClick={() => router.push('/gallery')}
                    >
                      <LayoutGrid className="h-4 w-4 mr-2" />
                      Ver Galeria
                    </Button>
                  </div>
                </CardContent>
              </Card>
            </motion.div>
          </div>
        </section>
      </div>
    </div>
  )
}

export default HomePage